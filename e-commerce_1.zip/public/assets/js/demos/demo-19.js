// Demo 19 Js file
$(document).ready(function () {
    'use strict';
});