<?php if (isset($component)) { $__componentOriginalf5682d52124c809e5d0dadbe61dad0a8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf5682d52124c809e5d0dadbe61dad0a8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.body','data' => ['items' => $items,'category' => $category]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($items),'category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category)]); ?>
    <main class="main">
        <div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
            <div class="container">
                <h1 class="page-title">Shopping Cart<span>Shop</span></h1>
            </div><!-- End .container -->
        </div><!-- End .page-header -->
        <nav aria-label="breadcrumb" class="breadcrumb-nav">
            <div class="container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Shop</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>
                </ol>
            </div><!-- End .container -->
        </nav><!-- End .breadcrumb-nav -->

        <div class="page-content">
            <div class="cart">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9">
                            <table class="table table-cart table-mobile">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Total</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <?php if(!empty(session("cart"))): ?>
                                <tbody>
                                    <?php
                                        $total = 0;
                                    ?>
                                  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td class="product-col">
                                        <div class="product">
                                            <figure class="product-media">
                                                <a href="<?php echo e(url("/product/$item->id")); ?>">
                                                    <img src="<?php echo e(asset("productimages/$item->image")); ?>" alt="Product image">
                                                </a>
                                            </figure>

                                            <h3 class="product-title">
                                                <a href="<?php echo e(url("/product/$item->id")); ?>"><?php echo e($item->name); ?></a>
                                            </h3><!-- End .product-title -->
                                        </div><!-- End .product -->
                                    </td>
                                    <td class="price-col">$<?php echo e($item->price); ?></td>
                                    <td class="quantity-col">
                                        <div class="cart-product-quantity">
                                            <input disabled type="number" class="form-control" value="<?php echo e(session("cart")[$item->id]); ?>" min="1" max="10" step="1" data-decimals="0" required>
                                        </div><!-- End .cart-product-quantity -->
                                    </td>
                                    <td class="total-col">$<?php echo e($item->price * session("cart")[$item->id]); ?></td>
                                    <td class="remove-col"><a href="<?php echo e(url("/cart/remove/$item->id")); ?>" class="btn-remove"><i class="icon-close"></i></a></td>
                                </tr>
                                <?php
                                $total = $total + ($item->price * session("cart")[$item->id]);
                            ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                </tbody>
                                <?php else: ?>
                                <div class="alert alert-info"> Cart Empty</div>
                                <?php endif; ?>
                                
                            </table><!-- End .table table-wishlist -->

                            <div class="cart-bottom">
                               

                               
                                <form class="m-2" action="<?php echo e(route("cart.empty")); ?>" method="post">
                                    
                                    <?php echo csrf_field(); ?><button type="submit" class="btn btn-dark"><span>Empty CART</span><i class="fa fa-bin"></i></button></form>
                               
                            </div><!-- End .cart-bottom -->
                        </div><!-- End .col-lg-9 -->
                        <aside class="col-lg-3">
                            <div class="summary summary-cart">
                                <h3 class="summary-title">Cart Total</h3><!-- End .summary-title -->

                                <table class="table table-summary">
                                    <tbody>
                                      
                                        <tr class="summary-total">
                                            <td>Total:</td>
                                            <td>$<?php echo e(isset($total) ? $total : 0); ?></td>
                                        </tr><!-- End .summary-total -->
                                    </tbody>
                                </table><!-- End .table table-summary -->

                                <a href="<?php echo e(route("cart.checkout")); ?>" class="btn btn-outline-primary-2 btn-order btn-block">PROCEED TO CHECKOUT</a>
                            </div><!-- End .summary -->

                            <a href="/allcategories/" class="btn btn-outline-dark-2 btn-block mb-3"><span>CONTINUE SHOPPING</span><i class="icon-refresh"></i></a>
                        </aside><!-- End .col-lg-3 -->
                    </div><!-- End .row -->
                </div><!-- End .container -->
            </div><!-- End .cart -->
        </div><!-- End .page-content -->
    </main><!-- End .main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf5682d52124c809e5d0dadbe61dad0a8)): ?>
<?php $attributes = $__attributesOriginalf5682d52124c809e5d0dadbe61dad0a8; ?>
<?php unset($__attributesOriginalf5682d52124c809e5d0dadbe61dad0a8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5682d52124c809e5d0dadbe61dad0a8)): ?>
<?php $component = $__componentOriginalf5682d52124c809e5d0dadbe61dad0a8; ?>
<?php unset($__componentOriginalf5682d52124c809e5d0dadbe61dad0a8); ?>
<?php endif; ?><?php /**PATH C:\Users\UC-tech\Desktop\laravel projects\e-commerce_1\resources\views/ecommerce/cart.blade.php ENDPATH**/ ?>