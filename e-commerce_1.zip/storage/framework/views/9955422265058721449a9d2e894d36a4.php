<?php if (isset($component)) { $__componentOriginal76b21ca4da47f56e4af33856a53757ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76b21ca4da47f56e4af33856a53757ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admindash','data' => ['admin' => $admin]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admindash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin)]); ?>
 <div class="container">
    <div class="row">
        <div class="col">
            <form action="<?php echo e(route("admin.edit.products")); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
             <?php echo csrf_field(); ?>
             <div class="col-sm-12 col-xl-6">
                 <div class="bg-light rounded h-100 p-4">
                     <h3 class="mb-4">Edit a Product</h3>
                     <div class="form-floating mb-3">
                         <input name="name" value="<?php echo e($product->name); ?>" type="text" class="form-control" id="floatingInput"
                             placeholder="product name">
                         <label for="floatingInput">Product Name</label>
                         <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <p class="text-danger"><?php echo e($message); ?></p>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="form-floating mb-3">
                         <input name="price" value="<?php echo e($product->price); ?>" type="text" class="form-control" id="floatingInput"
                             placeholder="Price">
                         <label for="floatingInput">Product Price</label>
                         <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <p class="text-danger"><?php echo e($message); ?></p>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="form-floating mb-3">
                         <select name="cat" class="form-select" id="floatingSelect"
                             aria-label="Floating label select example">
                             <option value="" selected>Select the category fo your product</option>
                             <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option <?php echo e($product->category->id == $cat->id ? "selected" : ""); ?> value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?> </option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                             
                         </select>
                         <label for="floatingSelect">Categories</label>
                         <?php $__errorArgs = ['cat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <p class="text-danger"><?php echo e($message); ?></p>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         
                     </div>
                     <div class="form-floating mb-3">
                         <textarea name="desc" class="form-control" placeholder="Leave a comment here"
                             id="floatingTextarea" style="height: 150px;"><?php echo e($product->description); ?></textarea>
                         <label for="floatingTextarea">Description</label>
                         <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <p class="text-danger"><?php echo e($message); ?></p>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="mb-3">
                         <label for="formFile" class="form-label">Choose the image file for the product</label>
                         <input name="image" class="form-control" type="file" id="formFile">
                         <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <p class="text-danger"><?php echo e($message); ?></p>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <button class="btn btn-outline-primary w-100 m-2" type="submit">Edit Product</button>
                 </div>
             </div>
            </form>
        </div>
    </div>
 </div>
 
 
    
  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76b21ca4da47f56e4af33856a53757ea)): ?>
<?php $attributes = $__attributesOriginal76b21ca4da47f56e4af33856a53757ea; ?>
<?php unset($__attributesOriginal76b21ca4da47f56e4af33856a53757ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76b21ca4da47f56e4af33856a53757ea)): ?>
<?php $component = $__componentOriginal76b21ca4da47f56e4af33856a53757ea; ?>
<?php unset($__componentOriginal76b21ca4da47f56e4af33856a53757ea); ?>
<?php endif; ?><?php /**PATH C:\Users\UC-tech\Desktop\laravel projects\e-commerce_1\resources\views/admin/editproduct.blade.php ENDPATH**/ ?>