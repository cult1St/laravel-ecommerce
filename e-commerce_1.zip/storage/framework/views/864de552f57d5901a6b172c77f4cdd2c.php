<?php if (isset($component)) { $__componentOriginal76b21ca4da47f56e4af33856a53757ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76b21ca4da47f56e4af33856a53757ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admindash','data' => ['admin' => $admin]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admindash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin)]); ?>
    <?php if(session("message")): ?>
    <div class="alert alert-success"><?php echo e(session("message")); ?></div>
    <?php endif; ?>
  <div class="container">
    <div class="row">
        <div class="col">
            <div class="m-2 bg-light rounded h-100 p-4 table-responsive">
                <h6 class="mb-4">Basic Table</h6>
                <table class="table table-bordered ">
                    <thead>
                        <tr>
                            <th scope="col">S/N</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Product Image</th>
                            <th scope="col">Product Description</th>
                            <th scope="col">Product Price</th>
                            <th scope="col">Product Category</th>
                            <th scope="col">Status</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($p->name); ?></td>
                            <td><img src="<?php echo e(asset("productimages/$p->image")); ?>" style="width: 100px" alt=""></td>
                            <td><?php echo e(substr($p->description, 0, 100)); ?>...</td>
                            <td><?php echo e($p->price); ?></td>
                            <td><?php echo e($p->category->name); ?></td>
                            <td><?php echo e($p->status); ?></td>
                            <td>
                                <form action="<?php echo e(route("admin.edit.product")); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
                                    <button type="submit" class="btn btn-info m-2">Edit</button>
                                </form>
                                <form action="<?php echo e(route("admin.delete.product")); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("delete"); ?>
                                    <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
                                    <button type="submit" onclick="confirm('Are you sure you want to delete this product <?php echo e($p->name); ?>')" class="btn btn-danger m-2">Delete</button>
                                </form>
                            </td>
                            <td>
                                <form id="status_change">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status" id="inlineRadio1"
                                            value="available" <?php echo e($p->status=="available" ? "checked" : ""); ?>>
                                        <label class="form-check-label" for="inlineRadio1">Available</label>
                                    </div>
                                    <input type="hidden" name="prodId" value="<?php echo e($p->id); ?>">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status" id="inlineRadio2"
                                            value="not_available" <?php echo e($p->status=="not_available" ? "checked" : ""); ?>>
                                        <label class="form-check-label" for="inlineRadio2">Not Available</label>
                                    </div>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                       
                    </tbody>
                </table>
            </div>
        </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76b21ca4da47f56e4af33856a53757ea)): ?>
<?php $attributes = $__attributesOriginal76b21ca4da47f56e4af33856a53757ea; ?>
<?php unset($__attributesOriginal76b21ca4da47f56e4af33856a53757ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76b21ca4da47f56e4af33856a53757ea)): ?>
<?php $component = $__componentOriginal76b21ca4da47f56e4af33856a53757ea; ?>
<?php unset($__componentOriginal76b21ca4da47f56e4af33856a53757ea); ?>
<?php endif; ?><?php /**PATH C:\Users\UC-tech\Desktop\laravel projects\e-commerce_1\resources\views/admin/viewproducts.blade.php ENDPATH**/ ?>