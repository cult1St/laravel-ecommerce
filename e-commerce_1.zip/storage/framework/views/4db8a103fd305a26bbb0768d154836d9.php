<?php if (isset($component)) { $__componentOriginal76b21ca4da47f56e4af33856a53757ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76b21ca4da47f56e4af33856a53757ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admindash','data' => ['admin' => $admin]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admindash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin)]); ?>
    <?php if(session("message")): ?>
    <div class="alert alert-success"><?php echo e(session("message")); ?></div>
    <?php endif; ?>
  <div class="container">
    <div class="row">
        <div class="col">
            <div class="m-2 bg-light rounded h-100 p-4 table-responsive">
                <h6 class="mb-4">Order Table</h6>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>User</th>
                            <th>Date</th>
                            <th>Location</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($order->user->name); ?></td>
                                <td><?php echo e($order->created_at); ?></td>
                                <td><?php echo e($order->state->name); ?></td>
                                <th><?php echo e($order->status); ?></th>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76b21ca4da47f56e4af33856a53757ea)): ?>
<?php $attributes = $__attributesOriginal76b21ca4da47f56e4af33856a53757ea; ?>
<?php unset($__attributesOriginal76b21ca4da47f56e4af33856a53757ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76b21ca4da47f56e4af33856a53757ea)): ?>
<?php $component = $__componentOriginal76b21ca4da47f56e4af33856a53757ea; ?>
<?php unset($__componentOriginal76b21ca4da47f56e4af33856a53757ea); ?>
<?php endif; ?><?php /**PATH C:\Users\UC-tech\Desktop\laravel projects\e-commerce_1\resources\views/admin/view_orders.blade.php ENDPATH**/ ?>