<?php if (isset($component)) { $__componentOriginal76b21ca4da47f56e4af33856a53757ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76b21ca4da47f56e4af33856a53757ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admindash','data' => ['admin' => $admin]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admindash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin)]); ?>

<?php if(session("message")): ?>
    <div class="alert alert-success"><?php echo e(session("message")); ?></div>
<?php endif; ?>
<div class="container-fluid pt-4 px-4">
   <div class="row g-4">
    <div class="col-sm-6 col-md-3 col-xl-3">
        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
            <i class="fa fa-chart-line fa-3x text-primary"></i>
            <div class="ms-3">
                <p class="mb-2">Total Products</p>
                <h6 class="mb-0"><?php echo e(count($products)); ?></h6>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3 col-xl-3">
        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
            <i class="fa fa-chart-bar fa-3x text-primary"></i>
            <div class="ms-3">
                <p class="mb-2">Total Orders</p>
                <h6 class="mb-0"><?php echo e(count($orders)); ?></h6>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3 col-xl-3">
        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
            <i class="fa fa-chart-area fa-3x text-primary"></i>
            <div class="ms-3">
                <p class="mb-2">Today Payments</p>
                <h6 class="mb-0"><?php echo e(count($payments)); ?></h6>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3  col-xl-3">
        <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
            <i class="fa fa-chart-pie fa-3x text-primary"></i>
            <div class="ms-3">
                <p class="mb-2">Total Users</p>
                <h6 class="mb-0"><?php echo e(count($users)); ?></h6>
            </div>
        </div>
    </div>
</div>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76b21ca4da47f56e4af33856a53757ea)): ?>
<?php $attributes = $__attributesOriginal76b21ca4da47f56e4af33856a53757ea; ?>
<?php unset($__attributesOriginal76b21ca4da47f56e4af33856a53757ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76b21ca4da47f56e4af33856a53757ea)): ?>
<?php $component = $__componentOriginal76b21ca4da47f56e4af33856a53757ea; ?>
<?php unset($__componentOriginal76b21ca4da47f56e4af33856a53757ea); ?>
<?php endif; ?>
<?php /**PATH C:\Users\UC-tech\Desktop\laravel projects\e-commerce_1\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>