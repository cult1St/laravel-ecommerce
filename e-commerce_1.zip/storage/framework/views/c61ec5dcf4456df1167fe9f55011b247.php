<?php if (isset($component)) { $__componentOriginalf5682d52124c809e5d0dadbe61dad0a8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf5682d52124c809e5d0dadbe61dad0a8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.body','data' => ['items' => $items]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($items)]); ?>
    <main class="main">
        <div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
            <div class="container">
                <h1 class="page-title">My Account<span>Shop</span></h1>
            </div><!-- End .container -->
        </div><!-- End .page-header -->
        <nav aria-label="breadcrumb" class="breadcrumb-nav mb-3">
            <div class="container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Shop</a></li>
                    <li class="breadcrumb-item active" aria-current="page">My Account</li>
                </ol>
            </div><!-- End .container -->
        </nav><!-- End .breadcrumb-nav -->

        <div class="page-content">
            <div class="dashboard">
                <div class="container">
                    <div class="row">
                        <aside class="col-md-4 col-lg-3">
                            <ul class="nav nav-dashboard flex-column mb-3 mb-md-0" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="tab-dashboard-link" data-toggle="tab" href="#tab-dashboard" role="tab" aria-controls="tab-dashboard" aria-selected="true">Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="tab-orders-link" data-toggle="tab" href="#tab-orders" role="tab" aria-controls="tab-orders" aria-selected="false">Orders</a>
                                </li>
                                 <li class="nav-item">
                                    <a class="nav-link" id="tab-cred-link" data-toggle="tab" href="#tab-cred" role="tab" aria-controls="tab-cred" aria-selected="false">Edit Credentials</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route("cart.view")); ?>">Cart</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route("cart.checkout")); ?>">Checkout</a>
                                </li>
                                <li class="nav-item">
                                    <form action="<?php echo e(route("logout")); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn" >Sign Out</button>
                                    </form>
                                    
                                </li>
                            </ul>
                        </aside><!-- End .col-lg-3 -->

                        <div class="col-md-8 col-lg-9">
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="tab-dashboard" role="tabpanel" aria-labelledby="tab-dashboard-link">
                                    <p>Hello <span class="font-weight-normal text-dark"><?php echo e(Auth::user()->name); ?></span> 
                                    <br>
                                    From your account dashboard you can  <a class="text-warning" href="#tab-cred" class="tab-trigger-link">edit your password and account details</a>.</p>
                                </div><!-- .End .tab-pane -->
                                <div class="tab-pane fade" id="tab-cred" role="tabpanel" aria-labelledby="tab-cred-link">
                                    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                        <div class="py-12">
                                            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
                                            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                                                <div class="max-w-xl">
                                                    <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                
                                            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                                                <div class="max-w-xl">
                                                    <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                
                                            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                                                <div class="max-w-xl">
                                                    <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
                                  
                                </div><!-- .End .tab-pane -->

                                <div class="tab-pane fade" id="tab-orders" role="tabpanel" aria-labelledby="tab-orders-link">
                                    <div class="card table-responsive">
                                       <div class="card-header">
                                        <h2 class="text-warning"> <i class="fa fa-shop"></i>Your orders</h2>
                                       </div>
                                       <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>Address</th>
                                                    <th>State</th>
                                                    <th>LGA</th>
                                                    <th>Date and Time ordered</th>
                                                    <th>Status</th>
                                                    <th>Products</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($order->address); ?></td>
                                                        <td><?php echo e($order->state->name); ?></td>
                                                        <td><?php echo e($order->lga->name); ?></td>
                                                        <td><?php echo e($order->created_at); ?></td>
                                                        <td><?php echo e($order->status); ?></td>
                                                        <td>
                                                            <div class="row">
                                                               <?php $__currentLoopData = $order->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                               <div class="col-md-3">
                                                                <a href="<?php echo e(url("/product/$p->id")); ?>"><img src="<?php echo e(asset("productimages/$p->image")); ?>" class="img-fluid" alt="<?php echo e($p->name); ?> Image"><p><?php echo e($p->name); ?></p></a>
                                                                </div>
                                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                       </div>
                                     
                                    </div>
                                    <p>No order has been made yet.</p>
                                    <a href="category.html" class="btn btn-outline-primary-2"><span>GO SHOP</span><i class="icon-long-arrow-right"></i></a>
                                </div><!-- .End .tab-pane -->
                            </div>
                        </div><!-- End .col-lg-9 -->
                    </div><!-- End .row -->
                </div><!-- End .container -->
            </div><!-- End .dashboard -->
        </div><!-- End .page-content -->
    </main><!-- End .main -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf5682d52124c809e5d0dadbe61dad0a8)): ?>
<?php $attributes = $__attributesOriginalf5682d52124c809e5d0dadbe61dad0a8; ?>
<?php unset($__attributesOriginalf5682d52124c809e5d0dadbe61dad0a8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5682d52124c809e5d0dadbe61dad0a8)): ?>
<?php $component = $__componentOriginalf5682d52124c809e5d0dadbe61dad0a8; ?>
<?php unset($__componentOriginalf5682d52124c809e5d0dadbe61dad0a8); ?>
<?php endif; ?><?php /**PATH C:\Users\UC-tech\Desktop\laravel projects\e-commerce_1\resources\views/ecommerce/dashboard.blade.php ENDPATH**/ ?>